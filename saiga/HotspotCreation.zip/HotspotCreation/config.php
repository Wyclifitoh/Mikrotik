<?php 
$host = "192.168.88.1";
$user = "admin";
$pass = "kyssanet";
?>